-- Copyright 2025 SmartThings, Inc.
-- Licensed under the Apache License, Version 2.0

local lazy_load_if_possible = require "lazy_load_subdriver"
local sub_drivers = {
   lazy_load_if_possible("frient"),
   lazy_load_if_possible("aqara-gas"),
   lazy_load_if_possible("aqara"),
   lazy_load_if_possible("MultiIR"),
   lazy_load_if_possible("heiman-hs1sa-e-plus"),
}
return sub_drivers
