-- Copyright 2024 SmartThings, Inc.
-- Licensed under the Apache License, Version 2.0

local data_types = require "st.zigbee.data_types"
local clusters = require "st.zigbee.zcl.clusters"
local cluster_base = require "st.zigbee.cluster_base"
local battery_defaults = require "st.zigbee.defaults.battery_defaults"
local capabilities = require "st.capabilities"


local selfCheck = capabilities["stse.selfCheck"]
local startSelfCheckCommandName = "startSelfCheck"

local PRIVATE_CLUSTER_ID = 0xFCC0
local PRIVATE_ATTRIBUTE_ID = 0x0009
local MFG_CODE = 0x115F
local PRIVATE_MUTE_ATTRIBUTE_ID = 0x0126
local PRIVATE_SELF_CHECK_ATTRIBUTE_ID = 0x0127
local PRIVATE_SMOKE_ZONE_STATUS_ATTRIBUTE_ID = 0x013A
local PowerConfiguration = clusters.PowerConfiguration




local CONFIGURATIONS = {
  {
    cluster = PRIVATE_CLUSTER_ID,
    attribute = PRIVATE_SMOKE_ZONE_STATUS_ATTRIBUTE_ID,
    minimum_interval = 1,
    maximum_interval = 3600,
    data_type = data_types.Uint16,
    reportable_change = 1
  },
  {
    cluster = PowerConfiguration.ID,
    attribute = PowerConfiguration.attributes.BatteryVoltage.ID,
    minimum_interval = 30,
    maximum_interval = 3600,
    data_type = PowerConfiguration.attributes.BatteryVoltage.base_type,
    reportable_change = 1
  }
}

local function smoke_zone_status_handler(driver, device, value, zb_rx)
  if value.value == 1 then
    device:emit_event(capabilities.smokeDetector.smoke.detected())
  elseif value.value == 0 then
    device:emit_event(capabilities.smokeDetector.smoke.clear())
  end
end

local function buzzer_status_handler(driver, device, value, zb_rx)
  if value.value == 1 then
    device:emit_event(capabilities.audioMute.mute.muted())
  elseif value.value == 0 then
    device:emit_event(capabilities.audioMute.mute.unmuted())
  end
end


local function selfcheck_status_handler(driver, device, value, zb_rx)
  if value.value == 0 then
    device:emit_event(selfCheck.selfCheckState.idle())
  elseif value.value == 1 then
    device:emit_event(selfCheck.selfCheckState.selfCheckCompleted())
  end
end



local function mute_handler(driver, device, cmd)
  device:send(cluster_base.write_manufacturer_specific_attribute(device,
    PRIVATE_CLUSTER_ID, PRIVATE_MUTE_ATTRIBUTE_ID, MFG_CODE, data_types.Uint8, 1))
end

local function unmute_handler(driver, device, cmd)
  device:send(cluster_base.write_manufacturer_specific_attribute(device,
    PRIVATE_CLUSTER_ID, PRIVATE_MUTE_ATTRIBUTE_ID, MFG_CODE, data_types.Uint8, 0))
end


local function self_check_attr_handler(self, device, zone_status, zb_rx)
  device:emit_event(selfCheck.selfCheckState.selfChecking())
  device:send(cluster_base.write_manufacturer_specific_attribute(device,
    PRIVATE_CLUSTER_ID, PRIVATE_SELF_CHECK_ATTRIBUTE_ID, MFG_CODE, data_types.Boolean, true))
end


local function device_init(driver, device)
  battery_defaults.build_linear_voltage_init(2.6, 3.0)(driver, device)
  if CONFIGURATIONS ~= nil then
    for _, attribute in ipairs(CONFIGURATIONS) do
      device:add_configured_attribute(attribute)
    end
  end
end

local function device_added(driver, device)
  device:emit_event(capabilities.smokeDetector.smoke.clear())
  device:emit_event(capabilities.audioMute.mute.unmuted())
  device:emit_event(selfCheck.selfCheckState.idle())
  device:emit_event(capabilities.battery.battery(100))
end

local function do_configure(self, device)
  device:configure()
  device:send(cluster_base.write_manufacturer_specific_attribute(device,
    PRIVATE_CLUSTER_ID, PRIVATE_ATTRIBUTE_ID, MFG_CODE, data_types.Uint8, 0x01))
end

local aqara_gas_detector_handler = {
  NAME = "Aqara Smoke Detector Handler",
  lifecycle_handlers = {
    init = device_init,
    added = device_added,
    doConfigure = do_configure
  },
  zigbee_handlers = {
    attr = {
      [PRIVATE_CLUSTER_ID] = {
        [PRIVATE_SMOKE_ZONE_STATUS_ATTRIBUTE_ID] = smoke_zone_status_handler,
        [PRIVATE_MUTE_ATTRIBUTE_ID] = buzzer_status_handler,
        [PRIVATE_SELF_CHECK_ATTRIBUTE_ID] = selfcheck_status_handler
      },
    }
  },
  capability_handlers = {
    [capabilities.audioMute.ID] = {
      [capabilities.audioMute.commands.mute.NAME] = mute_handler,
      [capabilities.audioMute.commands.unmute.NAME] = unmute_handler
    },
    [selfCheck.ID] = {
      [startSelfCheckCommandName] = self_check_attr_handler
    },
  },
  can_handle = require("aqara.can_handle"),
}

return aqara_gas_detector_handler
